
function CreateFileRefs()
{
var fr=new Array();
            
fr[1]=['http://rosleshoz.gov.ru/xmlns/cTypes/4.2', 'http___rosleshoz_gov_ru_xmlns_ctypes_4_2.html'];
fr[2]=['http://rosleshoz.gov.ru/xmlns/forestDevelopmentProject/4.1', 'http___rosleshoz_gov_ru_xmlns_forestdevelopmentproject_4_1.html'];
fr[3]=['http://rosleshoz.gov.ru/xmlns/sTypes/4.1', 'http___rosleshoz_gov_ru_xmlns_stypes_4_1.html'];
fr[4]=['cTypes.xsd', 'ctypes_xsd.html'];
fr[5]=['attachments', 'attachments.html'];
fr[6]=['file', 'file.html'];
fr[7]=['contract', 'contract.html'];
fr[8]=['date', 'date.html'];
fr[9]=['number', 'number.html'];
fr[10]=['type', 'type.html'];
fr[11]=['coordinates', 'coordinates.html'];
fr[12]=['latitude', 'latitude.html'];
fr[13]=['longitude', 'longitude.html'];
fr[14]=['date', 'date1.html'];
fr[15]=['month', 'month.html'];
fr[16]=['year', 'year.html'];
fr[17]=['employee', 'employee.html'];
fr[18]=['basisAuthority', 'basisauthority.html'];
fr[19]=['date', 'date2.html'];
fr[20]=['first_name', 'first_name.html'];
fr[21]=['last_name', 'last_name.html'];
fr[22]=['number', 'number1.html'];
fr[23]=['patronimic_name', 'patronimic_name.html'];
fr[24]=['phone', 'phone.html'];
fr[25]=['post', 'post.html'];
fr[26]=['file', 'file1.html'];
fr[27]=['extension', 'extension.html'];
fr[28]=['id', 'id.html'];
fr[29]=['name', 'name.html'];
fr[30]=['signature', 'signature.html'];
fr[31]=['individualEntrepreneur', 'individualentrepreneur.html'];
fr[32]=['first_name', 'first_name1.html'];
fr[33]=['inn', 'inn.html'];
fr[34]=['last_name', 'last_name1.html'];
fr[35]=['patronimic_name', 'patronimic_name1.html'];
fr[36]=['juridicalPerson', 'juridicalperson.html'];
fr[37]=['inn', 'inn1.html'];
fr[38]=['name', 'name1.html'];
fr[39]=['location', 'location.html'];
fr[40]=['cuttingArea', 'cuttingarea.html'];
fr[41]=['forestry', 'forestry.html'];
fr[42]=['quarter', 'quarter.html'];
fr[43]=['subforestry', 'subforestry.html'];
fr[44]=['taxationUnit', 'taxationunit.html'];
fr[45]=['tract', 'tract.html'];
fr[46]=['partner', 'partner.html'];
fr[47]=['individualEntrepreneur', 'individualentrepreneur1.html'];
fr[48]=['juridicalPerson', 'juridicalperson1.html'];
fr[49]=['physicalPerson', 'physicalperson.html'];
fr[50]=['period', 'period.html'];
fr[51]=['begin', 'begin.html'];
fr[52]=['end', 'end.html'];
fr[53]=['physicalPerson', 'physicalperson1.html'];
fr[54]=['first_name', 'first_name2.html'];
fr[55]=['identity_document', 'identity_document.html'];
fr[56]=['name', 'name2.html'];
fr[57]=['number', 'number2.html'];
fr[58]=['series', 'series.html'];
fr[59]=['last_name', 'last_name2.html'];
fr[60]=['patronimic_name', 'patronimic_name2.html'];
fr[61]=['reference', 'reference.html'];
fr[62]=['description', 'description.html'];
fr[63]=['id', 'id1.html'];
fr[64]=['name', 'name3.html'];
fr[65]=['serviceInfo', 'serviceinfo.html'];
fr[66]=['guid', 'guid.html'];
fr[67]=['name', 'name4.html'];
fr[68]=['provider', 'provider.html'];
fr[69]=['version', 'version.html'];
fr[70]=['signerData', 'signerdata.html'];
fr[71]=['date', 'date3.html'];
fr[72]=['employee', 'employee1.html'];
fr[73]=['organization', 'organization.html'];
fr[74]=['forestDevelopmentProject.xsd', 'forestdevelopmentproject_xsd.html'];
fr[75]=['characteristicsWorkRow', 'characteristicsworkrow.html'];
fr[76]=['characteristic', 'characteristic.html'];
fr[77]=['typeWork', 'typework.html'];
fr[78]=['volume', 'volume.html'];
fr[79]=['forestDevelopmentProject', 'forestdevelopmentproject.html'];
fr[80]=['attachments', 'attachments1.html'];
fr[81]=['file', 'file2.html'];
fr[82]=['forestUse', 'forestuse.html'];
fr[83]=['agriculture', 'agriculture.html'];
fr[84]=['locationResource', 'locationresource.html'];
fr[85]=['row', 'row.html'];
fr[86]=['technologies', 'technologies.html'];
fr[87]=['volumeResource', 'volumeresource.html'];
fr[88]=['row', 'row1.html'];
fr[89]=['fishing', 'fishing.html'];
fr[90]=['characteristicsWork', 'characteristicswork.html'];
fr[91]=['row', 'row2.html'];
fr[92]=['locationObject', 'locationobject.html'];
fr[93]=['row', 'row3.html'];
fr[94]=['foodForestrResourcesHarvesting', 'foodforestrresourcesharvesting.html'];
fr[95]=['characteristics', 'characteristics.html'];
fr[96]=['locationResource', 'locationresource1.html'];
fr[97]=['row', 'row4.html'];
fr[98]=['technologies', 'technologies1.html'];
fr[99]=['volumeResource', 'volumeresource1.html'];
fr[100]=['row', 'row5.html'];
fr[101]=['forestNurseries', 'forestnurseries.html'];
fr[102]=['characteristicsWork', 'characteristicswork1.html'];
fr[103]=['row', 'row6.html'];
fr[104]=['locationWork', 'locationwork.html'];
fr[105]=['row', 'row7.html'];
fr[106]=['forestPlantations', 'forestplantations.html'];
fr[107]=['characteristicsWork', 'characteristicswork2.html'];
fr[108]=['row', 'row8.html'];
fr[109]=['locationWork', 'locationwork1.html'];
fr[110]=['row', 'row9.html'];
fr[111]=['geology', 'geology.html'];
fr[112]=['characteristicsWork', 'characteristicswork3.html'];
fr[113]=['row', 'row10.html'];
fr[114]=['locationMeasure', 'locationmeasure.html'];
fr[115]=['row', 'row11.html'];
fr[116]=['locationObject', 'locationobject1.html'];
fr[117]=['row', 'row12.html'];
fr[118]=['volumeCuttings', 'volumecuttings.html'];
fr[119]=['row', 'row13.html'];
fr[120]=['hunting', 'hunting.html'];
fr[121]=['locationMeasure', 'locationmeasure1.html'];
fr[122]=['row', 'row14.html'];
fr[123]=['locationObject', 'locationobject2.html'];
fr[124]=['row', 'row15.html'];
fr[125]=['hydrology', 'hydrology.html'];
fr[126]=['characteristicsWork', 'characteristicswork4.html'];
fr[127]=['row', 'row16.html'];
fr[128]=['locationObject', 'locationobject3.html'];
fr[129]=['row', 'row17.html'];
fr[130]=['volumeCuttings', 'volumecuttings1.html'];
fr[131]=['row', 'row18.html'];
fr[132]=['linearObjects', 'linearobjects.html'];
fr[133]=['characteristicsWork', 'characteristicswork5.html'];
fr[134]=['row', 'row19.html'];
fr[135]=['locationObject', 'locationobject4.html'];
fr[136]=['row', 'row20.html'];
fr[137]=['volumeCuttings', 'volumecuttings2.html'];
fr[138]=['row', 'row21.html'];
fr[139]=['nonTimberResourcesHarvesting', 'nontimberresourcesharvesting.html'];
fr[140]=['locationResource', 'locationresource2.html'];
fr[141]=['row', 'row22.html'];
fr[142]=['technologies', 'technologies2.html'];
fr[143]=['volumeResource', 'volumeresource2.html'];
fr[144]=['row', 'row23.html'];
fr[145]=['plantGrowing', 'plantgrowing.html'];
fr[146]=['characteristicsWork', 'characteristicswork6.html'];
fr[147]=['row', 'row24.html'];
fr[148]=['locationMeasure', 'locationmeasure2.html'];
fr[149]=['row', 'row25.html'];
fr[150]=['recreation', 'recreation.html'];
fr[151]=['locationCapitalObject', 'locationcapitalobject.html'];
fr[152]=['row', 'row26.html'];
fr[153]=['locationNonCapitalObject', 'locationnoncapitalobject.html'];
fr[154]=['row', 'row27.html'];
fr[155]=['treeRegister', 'treeregister.html'];
fr[156]=['row', 'row28.html'];
fr[157]=['age', 'age.html'];
fr[158]=['condition', 'condition.html'];
fr[159]=['diameter', 'diameter.html'];
fr[160]=['height', 'height.html'];
fr[161]=['number', 'number3.html'];
fr[162]=['tree', 'tree.html'];
fr[163]=['volumeCuttings', 'volumecuttings3.html'];
fr[164]=['row', 'row29.html'];
fr[165]=['researchActivities', 'researchactivities.html'];
fr[166]=['characteristicsWork', 'characteristicswork7.html'];
fr[167]=['row', 'row30.html'];
fr[168]=['locationMeasure', 'locationmeasure3.html'];
fr[169]=['row', 'row31.html'];
fr[170]=['resinHarvesting', 'resinharvesting.html'];
fr[171]=['locationResource', 'locationresource3.html'];
fr[172]=['row', 'row32.html'];
fr[173]=['area', 'area.html'];
fr[174]=['location', 'location1.html'];
fr[175]=['resinOutlet', 'resinoutlet.html'];
fr[176]=['tree', 'tree1.html'];
fr[177]=['typeHarvesting', 'typeharvesting.html'];
fr[178]=['technologies', 'technologies3.html'];
fr[179]=['volumeResource', 'volumeresource3.html'];
fr[180]=['row', 'row33.html'];
fr[181]=['completion', 'completion.html'];
fr[182]=['finished', 'finished.html'];
fr[183]=['maybe', 'maybe.html'];
fr[184]=['unprofitable', 'unprofitable.html'];
fr[185]=['used', 'used.html'];
fr[186]=['useful', 'useful.html'];
fr[187]=['surveyWork', 'surveywork.html'];
fr[188]=['characteristicsWork', 'characteristicswork8.html'];
fr[189]=['row', 'row34.html'];
fr[190]=['area', 'area1.html'];
fr[191]=['characteristics', 'characteristics1.html'];
fr[192]=['location', 'location2.html'];
fr[193]=['timberProcessing', 'timberprocessing.html'];
fr[194]=['characteristicsWork', 'characteristicswork9.html'];
fr[195]=['row', 'row35.html'];
fr[196]=['locationObject', 'locationobject5.html'];
fr[197]=['row', 'row36.html'];
fr[198]=['volumeCuttings', 'volumecuttings4.html'];
fr[199]=['row', 'row37.html'];
fr[200]=['woodHarvesting', 'woodharvesting.html'];
fr[201]=['locationCuttings', 'locationcuttings.html'];
fr[202]=['row', 'row38.html'];
fr[203]=['area', 'area2.html'];
fr[204]=['averageVolume', 'averagevolume.html'];
fr[205]=['formCutting', 'formcutting.html'];
fr[206]=['location', 'location3.html'];
fr[207]=['reforestationMethod', 'reforestationmethod.html'];
fr[208]=['samplePercentage', 'samplepercentage.html'];
fr[209]=['tree', 'tree2.html'];
fr[210]=['typeCutting', 'typecutting.html'];
fr[211]=['volume', 'volume1.html'];
fr[212]=['volumeCuttingsWood', 'volumecuttingswood.html'];
fr[213]=['row', 'row39.html'];
fr[214]=['area', 'area3.html'];
fr[215]=['farm', 'farm.html'];
fr[216]=['formCutting', 'formcutting1.html'];
fr[217]=['liquidVolume', 'liquidvolume.html'];
fr[218]=['rootVolume', 'rootvolume.html'];
fr[219]=['specialPurpose', 'specialpurpose.html'];
fr[220]=['typeCutting', 'typecutting1.html'];
fr[221]=['general', 'general.html'];
fr[222]=['address', 'address.html'];
fr[223]=['contactInformation', 'contactinformation.html'];
fr[224]=['contract', 'contract1.html'];
fr[225]=['developer', 'developer.html'];
fr[226]=['executiveAuthority', 'executiveauthority.html'];
fr[227]=['info', 'info.html'];
fr[228]=['averageTaxationRates', 'averagetaxationrates.html'];
fr[229]=['row', 'row40.html'];
fr[230]=['age', 'age1.html'];
fr[231]=['area', 'area4.html'];
fr[232]=['bonitet', 'bonitet.html'];
fr[233]=['completeness', 'completeness.html'];
fr[234]=['composition', 'composition.html'];
fr[235]=['farm', 'farm1.html'];
fr[236]=['growth', 'growth.html'];
fr[237]=['ripeAndOverripe', 'ripeandoverripe.html'];
fr[238]=['specialPurpose', 'specialpurpose1.html'];
fr[239]=['tree', 'tree3.html'];
fr[240]=['volume', 'volume2.html'];
fr[241]=['contamination', 'contamination.html'];
fr[242]=['row', 'row41.html'];
fr[243]=['area', 'area5.html'];
fr[244]=['location', 'location4.html'];
fr[245]=['typeContamination', 'typecontamination.html'];
fr[246]=['unitType', 'unittype.html'];
fr[247]=['volume', 'volume3.html'];
fr[248]=['distributionSpecialPurpose', 'distributionspecialpurpose.html'];
fr[249]=['row', 'row42.html'];
fr[250]=['area', 'area6.html'];
fr[251]=['percent', 'percent.html'];
fr[252]=['protectionCategory', 'protectioncategory.html'];
fr[253]=['specialPurpose', 'specialpurpose2.html'];
fr[254]=['encumbrances', 'encumbrances.html'];
fr[255]=['row', 'row43.html'];
fr[256]=['borderArea', 'borderarea.html'];
fr[257]=['typeEncumbrance', 'typeencumbrance.html'];
fr[258]=['listQuartersTaxationUnit', 'listquarterstaxationunit.html'];
fr[259]=['row', 'row44.html'];
fr[260]=['area', 'area7.html'];
fr[261]=['location', 'location5.html'];
fr[262]=['rarePlantsAnimals', 'rareplantsanimals.html'];
fr[263]=['row', 'row45.html'];
fr[264]=['basisProtection', 'basisprotection.html'];
fr[265]=['location', 'location6.html'];
fr[266]=['row', 'row46.html'];
fr[267]=['restrictions', 'restrictions.html'];
fr[268]=['species', 'species.html'];
fr[269]=['speciallyProtectedNaturalAreas', 'speciallyprotectednaturalareas.html'];
fr[270]=['row', 'row47.html'];
fr[271]=['event', 'event.html'];
fr[272]=['location', 'location7.html'];
fr[273]=['row', 'row48.html'];
fr[274]=['securityMode', 'securitymode.html'];
fr[275]=['speciallyProtectedNaturalArea', 'speciallyprotectednaturalarea.html'];
fr[276]=['surveys', 'surveys.html'];
fr[277]=['row', 'row49.html'];
fr[278]=['requisites', 'requisites.html'];
fr[279]=['surveyMaterials', 'surveymaterials.html'];
fr[280]=['measures', 'measures.html'];
fr[281]=['areaForestCare', 'areaforestcare.html'];
fr[282]=['row', 'row50.html'];
fr[283]=['annualArea', 'annualarea.html'];
fr[284]=['area', 'area8.html'];
fr[285]=['farm', 'farm2.html'];
fr[286]=['tree', 'tree4.html'];
fr[287]=['typeCare', 'typecare.html'];
fr[288]=['areaNeedReforestation', 'areaneedreforestation.html'];
fr[289]=['row', 'row51.html'];
fr[290]=['area', 'area9.html'];
fr[291]=['landCategory', 'landcategory.html'];
fr[292]=['location', 'location8.html'];
fr[293]=['characteristicFireClasses', 'characteristicfireclasses.html'];
fr[294]=['row', 'row52.html'];
fr[295]=['area', 'area10.html'];
fr[296]=['areaFireClasses_I', 'areafireclasses_i.html'];
fr[297]=['areaFireClasses_II', 'areafireclasses_ii.html'];
fr[298]=['areaFireClasses_III', 'areafireclasses_iii.html'];
fr[299]=['areaFireClasses_IV', 'areafireclasses_iv.html'];
fr[300]=['areaFireClasses_V', 'areafireclasses_v.html'];
fr[301]=['areaFireClasses_V', 'areafireclasses_v1.html'];
fr[302]=['location', 'location9.html'];
fr[303]=['middleClass', 'middleclass.html'];
fr[304]=['characteristicWaterObjects', 'characteristicwaterobjects.html'];
fr[305]=['row', 'row53.html'];
fr[306]=['area', 'area11.html'];
fr[307]=['location', 'location10.html'];
fr[308]=['row', 'row54.html'];
fr[309]=['waterObject', 'waterobject.html'];
fr[310]=['damageDeath', 'damagedeath.html'];
fr[311]=['row', 'row55.html'];
fr[312]=['areaDamage', 'areadamage.html'];
fr[313]=['areaDeath', 'areadeath.html'];
fr[314]=['location', 'location11.html'];
fr[315]=['name', 'name5.html'];
fr[316]=['specialPurpose', 'specialpurpose3.html'];
fr[317]=['designedFirePrevention', 'designedfireprevention.html'];
fr[318]=['row', 'row56.html'];
fr[319]=['availability', 'availability.html'];
fr[320]=['deadlines', 'deadlines.html'];
fr[321]=['designedAnnualVolume', 'designedannualvolume.html'];
fr[322]=['designedTotalVolume', 'designedtotalvolume.html'];
fr[323]=['firePreventionObject', 'firepreventionobject.html'];
fr[324]=['location', 'location12.html'];
fr[325]=['need', 'need.html'];
fr[326]=['typeEvent', 'typeevent.html'];
fr[327]=['unitType', 'unittype1.html'];
fr[328]=['fireEquipment', 'fireequipment.html'];
fr[329]=['row', 'row57.html'];
fr[330]=['availability', 'availability1.html'];
fr[331]=['location', 'location13.html'];
fr[332]=['name', 'name6.html'];
fr[333]=['need', 'need1.html'];
fr[334]=['regulations', 'regulations.html'];
fr[335]=['unitType', 'unittype2.html'];
fr[336]=['fociHarmfulOrganisms', 'fociharmfulorganisms.html'];
fr[337]=['row', 'row58.html'];
fr[338]=['area', 'area12.html'];
fr[339]=['location', 'location14.html'];
fr[340]=['measure', 'measure.html'];
fr[341]=['name', 'name7.html'];
fr[342]=['specialPurpose', 'specialpurpose4.html'];
fr[343]=['listForestCare', 'listforestcare.html'];
fr[344]=['row', 'row59.html'];
fr[345]=['area', 'area13.html'];
fr[346]=['location', 'location15.html'];
fr[347]=['tree', 'tree5.html'];
fr[348]=['typeCare', 'typecare1.html'];
fr[349]=['listProtection', 'listprotection.html'];
fr[350]=['row', 'row60.html'];
fr[351]=['area', 'area14.html'];
fr[352]=['location', 'location16.html'];
fr[353]=['measureProtection', 'measureprotection.html'];
fr[354]=['objectProtection', 'objectprotection.html'];
fr[355]=['unitType', 'unittype3.html'];
fr[356]=['volume', 'volume4.html'];
fr[357]=['listReforestation', 'listreforestation.html'];
fr[358]=['row', 'row61.html'];
fr[359]=['area', 'area15.html'];
fr[360]=['conditionsProjectedMethod', 'conditionsprojectedmethod.html'];
fr[361]=['landCategory', 'landcategory1.html'];
fr[362]=['location', 'location17.html'];
fr[363]=['listTaxationUnitRadioactiveZone', 'listtaxationunitradioactivezone.html'];
fr[364]=['row', 'row62.html'];
fr[365]=['area', 'area16.html'];
fr[366]=['contaminatedZone', 'contaminatedzone.html'];
fr[367]=['location', 'location18.html'];
fr[368]=['usageRestriction', 'usagerestriction.html'];
fr[369]=['prevention', 'prevention.html'];
fr[370]=['row', 'row63.html'];
fr[371]=['fertilizerUse', 'fertilizeruse.html'];
fr[372]=['annualVolume', 'annualvolume.html'];
fr[373]=['volume', 'volume5.html'];
fr[374]=['habitatProtection', 'habitatprotection.html'];
fr[375]=['annualVolume', 'annualvolume1.html'];
fr[376]=['volume', 'volume6.html'];
fr[377]=['improvingConditions', 'improvingconditions.html'];
fr[378]=['annualVolume', 'annualvolume2.html'];
fr[379]=['volume', 'volume7.html'];
fr[380]=['location', 'location19.html'];
fr[381]=['pesticideApplication', 'pesticideapplication.html'];
fr[382]=['annualVolume', 'annualvolume3.html'];
fr[383]=['volume', 'volume8.html'];
fr[384]=['sowing', 'sowing.html'];
fr[385]=['annualVolume', 'annualvolume4.html'];
fr[386]=['volume', 'volume9.html'];
fr[387]=['specialPurpose', 'specialpurpose5.html'];
fr[388]=['treatmentTtrees', 'treatmentttrees.html'];
fr[389]=['annualVolume', 'annualvolume5.html'];
fr[390]=['volume', 'volume10.html'];
fr[391]=['usePheromones', 'usepheromones.html'];
fr[392]=['annualVolume', 'annualvolume6.html'];
fr[393]=['volume', 'volume11.html'];
fr[394]=['reforestationPlan', 'reforestationplan.html'];
fr[395]=['row', 'row64.html'];
fr[396]=['combined', 'combined.html'];
fr[397]=['landCategory', 'landcategory2.html'];
fr[398]=['landing', 'landing.html'];
fr[399]=['natural', 'natural.html'];
fr[400]=['sowing', 'sowing1.html'];
fr[401]=['sanitaryRecreationalMeasures', 'sanitaryrecreationalmeasures.html'];
fr[402]=['row', 'row65.html'];
fr[403]=['area', 'area17.html'];
fr[404]=['businessVolume', 'businessvolume.html'];
fr[405]=['liquidVolume', 'liquidvolume1.html'];
fr[406]=['location', 'location20.html'];
fr[407]=['rationale', 'rationale.html'];
fr[408]=['sanritaryRecreationalMeasure', 'sanritaryrecreationalmeasure.html'];
fr[409]=['specialPurpose', 'specialpurpose6.html'];
fr[410]=['volume', 'volume12.html'];
fr[411]=['year', 'year1.html'];
fr[412]=['zonesRadioactiveContamination', 'zonesradioactivecontamination.html'];
fr[413]=['row', 'row66.html'];
fr[414]=['contaminatedZone', 'contaminatedzone1.html'];
fr[415]=['dosimetricControl', 'dosimetriccontrol.html'];
fr[416]=['installationWarningBoards', 'installationwarningboards.html'];
fr[417]=['location', 'location21.html'];
fr[418]=['otherEvents', 'otherevents.html'];
fr[419]=['radiationControl', 'radiationcontrol.html'];
fr[420]=['objects', 'objects.html'];
fr[421]=['locationObject', 'locationobject6.html'];
fr[422]=['row', 'row67.html'];
fr[423]=['volumeCuttings', 'volumecuttings5.html'];
fr[424]=['row', 'row68.html'];
fr[425]=['partner', 'partner1.html'];
fr[426]=['regulations', 'regulations1.html'];
fr[427]=['usageType', 'usagetype.html'];
fr[428]=['usePeriod', 'useperiod.html'];
fr[429]=['validityPeriod', 'validityperiod.html'];
fr[430]=['yearForestManagement', 'yearforestmanagement.html'];
fr[431]=['preamble', 'preamble.html'];
fr[432]=['contract', 'contract2.html'];
fr[433]=['grounds', 'grounds.html'];
fr[434]=['location', 'location22.html'];
fr[435]=['totalArea', 'totalarea.html'];
fr[436]=['usageType', 'usagetype1.html'];
fr[437]=['serviceInfo', 'serviceinfo1.html'];
fr[438]=['locationMeasureRow', 'locationmeasurerow.html'];
fr[439]=['area', 'area18.html'];
fr[440]=['location', 'location23.html'];
fr[441]=['measure', 'measure1.html'];
fr[442]=['unitType', 'unittype4.html'];
fr[443]=['volume', 'volume13.html'];
fr[444]=['year', 'year2.html'];
fr[445]=['locationObjectRow', 'locationobjectrow.html'];
fr[446]=['area', 'area19.html'];
fr[447]=['characteristic', 'characteristic1.html'];
fr[448]=['length', 'length.html'];
fr[449]=['liquidConiferVolume', 'liquidconifervolume.html'];
fr[450]=['liquidVolume', 'liquidvolume2.html'];
fr[451]=['location', 'location24.html'];
fr[452]=['measure', 'measure2.html'];
fr[453]=['object', 'object.html'];
fr[454]=['rootConiferVolume', 'rootconifervolume.html'];
fr[455]=['rootVolume', 'rootvolume1.html'];
fr[456]=['locationResourceRow', 'locationresourcerow.html'];
fr[457]=['location', 'location25.html'];
fr[458]=['resource', 'resource.html'];
fr[459]=['typeHarvesting', 'typeharvesting1.html'];
fr[460]=['unitType', 'unittype5.html'];
fr[461]=['volume', 'volume14.html'];
fr[462]=['locationWorkRow', 'locationworkrow.html'];
fr[463]=['area', 'area20.html'];
fr[464]=['location', 'location26.html'];
fr[465]=['typeWork', 'typework1.html'];
fr[466]=['volumeCuttingsRow', 'volumecuttingsrow.html'];
fr[467]=['area', 'area21.html'];
fr[468]=['liquidConiferVolume', 'liquidconifervolume1.html'];
fr[469]=['liquidVolume', 'liquidvolume3.html'];
fr[470]=['location', 'location27.html'];
fr[471]=['object', 'object1.html'];
fr[472]=['rootConiferVolume', 'rootconifervolume1.html'];
fr[473]=['rootVolume', 'rootvolume2.html'];
fr[474]=['volumeResourceRow', 'volumeresourcerow.html'];
fr[475]=['fund', 'fund.html'];
fr[476]=['fundAnnual', 'fundannual.html'];
fr[477]=['resource', 'resource1.html'];
fr[478]=['unitType', 'unittype6.html'];
fr[479]=['forestDevelopmentProject', 'forestdevelopmentproject1.html'];
fr[480]=['sTypes.xsd', 'stypes_xsd.html'];
fr[481]=['ageGroup', 'agegroup.html'];
fr[482]=['area', 'area22.html'];
fr[483]=['areaCutting', 'areacutting.html'];
fr[484]=['completeness', 'completeness1.html'];
fr[485]=['contractType', 'contracttype.html'];
fr[486]=['coordinateSystem', 'coordinatesystem.html'];
fr[487]=['cuttingArea', 'cuttingarea1.html'];
fr[488]=['farm', 'farm3.html'];
fr[489]=['forestUsageVolume', 'forestusagevolume.html'];
fr[490]=['formCutting', 'formcutting2.html'];
fr[491]=['guid', 'guid1.html'];
fr[492]=['municipalDistrictType', 'municipaldistricttype.html'];
fr[493]=['objectNumber', 'objectnumber.html'];
fr[494]=['percent', 'percent1.html'];
fr[495]=['quarter', 'quarter1.html'];
fr[496]=['taxationMethod', 'taxationmethod.html'];
fr[497]=['taxationUnit', 'taxationunit1.html'];
fr[498]=['typeObject', 'typeobject.html'];
fr[499]=['valueCutting', 'valuecutting.html'];
fr[500]=['year', 'year3.html'];    
 return fr;          
}

function CreateWordIndex()
{
var w=[
            
['--created',[4,74,480]],
['with',[4,74,480]],
['liquid',[4,74,480]],
['designer',[4,74,480]],
['edition',[4,74,480]],
['http',[4,5,6,39,41,43,45,46,47,48,49,70,72,74,79,82,83,84,85,87,88,89,90,91,92,93,94,96,97,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,143,144,145,146,147,148,149,150,151,152,153,154,163,164,165,166,167,168,169,170,171,172,187,188,189,193,194,195,196,197,198,199,200,212,221,227,228,229,241,242,248,249,254,255,258,259,262,263,269,270,276,277,280,281,282,288,289,293,294,304,305,310,311,317,318,328,329,336,337,343,344,349,350,357,358,363,364,369,370,394,395,401,402,412,413,420,421,422,423,424,431,435,479,480]],
['liquid-technologies',[4,74,480]],
['schema',[4,74,480]],
['xmlns',[4,5,6,39,41,43,45,46,47,48,49,70,72,74,79,82,83,84,85,87,88,89,90,91,92,93,94,96,97,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,143,144,145,146,147,148,149,150,151,152,153,154,163,164,165,166,167,168,169,170,171,172,187,188,189,193,194,195,196,197,198,199,200,212,221,227,228,229,241,242,248,249,254,255,258,259,262,263,269,270,276,277,280,281,282,288,289,293,294,304,305,310,311,317,318,328,329,336,337,343,344,349,350,357,358,363,364,369,370,394,395,401,402,412,413,420,421,422,423,424,431,435,479,480]],
['rosleshoz',[4,5,6,39,41,43,45,46,47,48,49,70,72,74,79,82,83,84,85,87,88,89,90,91,92,93,94,96,97,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,143,144,145,146,147,148,149,150,151,152,153,154,163,164,165,166,167,168,169,170,171,172,187,188,189,193,194,195,196,197,198,199,200,212,221,227,228,229,241,242,248,249,254,255,258,259,262,263,269,270,276,277,280,281,282,288,289,293,294,304,305,310,311,317,318,328,329,336,337,343,344,349,350,357,358,363,364,369,370,394,395,401,402,412,413,420,421,422,423,424,431,435,479,480]],
['stypes',[4,74,79,431,435,480]],
['elementformdefault',[4,74,480]],
['qualified',[4,74,480]],
['targetnamespace',[4,74,480]],
['ctypes',[4,5,6,39,41,43,45,46,47,48,49,70,72,74]],
['version',[4,65,69,74,437,480]],
['xmlschema',[4,74,480]],
['import',[4,74]],
['schemalocation',[4,74]],
['namespace',[4,74]],
['complextype',[4,5,7,11,14,17,26,31,36,39,46,50,53,55,61,65,70,74,75,79,80,82,83,84,87,89,90,92,94,96,99,101,102,104,106,107,109,111,112,114,116,118,120,121,123,125,126,128,130,132,133,135,137,139,140,143,145,146,148,150,151,153,155,156,163,165,166,168,170,171,172,179,180,187,188,189,193,194,196,198,200,201,202,212,213,221,227,228,229,241,242,248,249,254,255,258,259,262,263,265,269,270,272,276,277,280,281,282,288,289,293,294,304,305,307,310,311,317,318,328,329,336,337,343,344,349,350,357,358,363,364,369,370,371,374,377,381,384,388,391,394,395,401,402,412,413,420,421,423,431,438,445,456,462,466,474]],
['name',[4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500]],
['reference',[4,39,41,43,45,61,74,79,82,150,155,156,162,170,171,172,176,200,201,202,209,210,212,213,219,220,221,226,227,228,229,232,238,239,241,242,246,248,249,252,253,280,281,282,286,288,289,291,310,311,316,317,318,327,328,329,335,336,337,342,343,344,347,349,350,355,357,358,361,369,370,387,394,395,397,401,402,408,409,438,441,442,445,452,453,456,458,460,466,471,474,477,478]],
['annotation',[4,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,82,83,84,86,87,89,90,92,94,95,96,98,99,101,102,104,106,107,109,111,112,114,116,118,120,121,123,125,126,128,130,132,133,135,137,139,140,142,143,145,146,148,150,151,153,155,156,157,158,159,160,161,162,163,165,166,168,170,171,172,173,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,192,193,194,196,198,200,201,202,203,204,205,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,267,268,269,270,271,272,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,423,425,426,427,428,429,430,431,432,433,434,435,436,438,439,441,442,443,444,445,446,447,448,449,450,452,453,454,455,456,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500]],
['documentation',[4,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,82,83,84,86,87,89,90,92,94,95,96,98,99,101,102,104,106,107,109,111,112,114,116,118,120,121,123,125,126,128,130,132,133,135,137,139,140,142,143,145,146,148,150,151,153,155,156,157,158,159,160,161,162,163,165,166,168,170,171,172,173,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,192,193,194,196,198,200,201,202,203,204,205,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,267,268,269,270,271,272,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,423,425,426,427,428,429,430,431,432,433,434,435,436,438,439,441,442,443,444,445,446,447,448,449,450,452,453,454,455,456,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500]],
['Ссылка',[]],
['справочник',[4,61,74,79,221,227,228,229,235]],
['attribute',[4,61,62,63,64]],
['type',[4,5,6,7,8,10,11,12,13,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,35,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,55,56,57,58,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,316,317,318,319,321,322,324,325,327,328,329,330,331,333,335,336,337,338,339,340,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479]],
['string',[4,7,9,17,18,20,21,22,23,24,25,26,27,28,29,31,32,33,34,35,36,37,38,53,54,55,56,57,58,59,60,61,62,63,64,65,67,68,69,70,73,74,75,76,77,78,79,82,83,86,94,95,98,139,142,150,155,156,158,161,170,171,172,177,178,200,201,202,207,221,222,223,227,228,229,234,241,242,245,254,255,256,257,262,263,264,267,268,269,270,271,274,275,276,277,278,279,280,281,282,287,293,294,303,304,305,309,310,311,315,317,318,320,323,326,328,329,331,332,334,336,337,340,341,343,344,348,349,350,353,354,357,358,360,363,364,366,368,401,402,407,412,413,414,426,427,431,433,434,436,445,447,456,459,462,465,480,485,486,487,488,490,491,492,493,495,496,497,498]],
['optional',[4,41,43,45,61,62,63,162,176,209,210,219,220,226,232,238,239,246,252,253,286,291,316,327,335,342,347,355,361,387,397,408,409,441,442,452,453,458,460,471,477,478]],
['Идентификатор',[]],
['required',[4,41,43,45,61,64,162,176,209,210,219,220,226,232,238,239,246,252,253,286,291,316,327,335,342,347,355,361,387,397,408,409,441,442,452,453,458,460,471,477,478]],
['Наименование',[]],
['description',[4,41,43,45,61,62,162,176,209,210,219,220,226,232,238,239,246,252,253,286,291,316,327,335,342,347,355,361,387,397,408,409,441,442,452,453,458,460,471,477,478]],
['Описание',[]],
['элемента',[4,61,62]],
['заполняется',[4,61,62]],
['опционально',[4,61,62]],
['partner',[4,46,74,79,221,425]],
['организации',[4,46]],
['choice',[4,46]],
['element',[4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479]],
['juridicalperson',[4,36,46,48,425]],
['лицо',[4,46,48,49]],
['physicalperson',[4,46,49,53,425]],
['individualentrepreneur',[4,31,46,47,425]],
['Индивидуальный',[]],
['предприниматель',[4,46,47]],
['Сведения',[]],
['лесопользователе',[4,31,36,53]],
['sequence',[4,5,7,11,14,17,26,31,36,39,50,53,55,65,70,74,75,79,80,82,83,84,87,89,90,92,94,96,99,101,102,104,106,107,109,111,112,114,116,118,120,121,123,125,126,128,130,132,133,135,137,139,140,143,145,146,148,150,151,153,155,156,163,165,166,168,170,171,172,179,180,187,188,189,193,194,196,198,200,201,202,212,213,221,227,228,229,241,242,248,249,254,255,258,259,262,263,265,269,270,272,276,277,280,281,282,288,289,293,294,304,305,307,310,311,317,318,328,329,336,337,343,344,349,350,357,358,363,364,369,370,371,374,377,381,384,388,391,394,395,401,402,412,413,420,421,423,431,438,445,456,462,466,474]],
['юридического',[4,36,38,74,79,221,222]],
['лица',[4,31,33,36,38,74,79,221,222]],
['включая',[4,36,38]],
['организационно-правовую',[4,36,38]],
['форму',[4,36,38]],
['simpletype',[4,7,9,14,15,16,31,32,33,34,36,37,38,53,54,59,74,79,221,280,310,311,315,317,318,320,323,326,328,329,332,334,336,337,341,363,364,366,412,413,414,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500]],
['restriction',[4,7,9,14,15,16,31,32,33,34,36,37,38,53,54,59,74,79,221,280,310,311,315,317,318,320,323,326,328,329,332,334,336,337,341,363,364,366,412,413,414,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500]],
['base',[4,7,9,14,15,16,31,32,33,34,36,37,38,53,54,59,74,79,221,280,310,311,315,317,318,320,323,326,328,329,332,334,336,337,341,363,364,366,412,413,414,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500]],
['minlength',[4,7,9,31,32,34,36,38,53,54,59,480,493]],
['value',[4,7,9,14,15,16,31,32,33,34,36,37,38,53,54,59,74,79,221,280,310,311,315,317,318,320,323,326,328,329,332,334,336,337,341,363,364,366,412,413,414,480,481,482,483,484,487,488,489,490,491,492,493,494,496,498,499]],
['default',[4,7,9,11,12,13,14,15,16,31,33,36,37,65,66,69,70,71]],
['length',[4,31,33,36,37,74,93,117,124,129,136,152,154,197,422,445,448]],
['pattern',[4,31,33,36,37,480,491]],
['first',[4,17,20,31,32,47,49,53,54,72]],
['last',[4,17,21,31,34,47,49,53,59,72]],
['Фамилия',[]],
['patronimic',[4,17,23,31,35,47,49,53,60,72]],
['minoccurs',[4,5,11,12,13,17,18,19,22,23,24,25,26,30,31,35,39,40,45,53,60,65,66,70,71,73,74,79,80,81,82,83,84,85,87,88,89,90,91,92,93,94,96,97,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,143,144,145,146,147,148,149,150,151,152,153,154,155,156,163,164,165,166,167,168,169,170,171,172,179,180,187,188,189,193,194,195,196,197,198,199,200,201,202,212,213,221,227,228,229,241,242,248,249,252,254,255,258,259,262,263,265,266,269,270,272,273,276,277,280,281,282,288,289,293,294,304,305,307,308,310,311,317,318,328,329,336,337,343,344,349,350,357,358,363,364,369,370,394,395,401,402,412,413,420,421,422,423,424,438,442,443,444,445,447,448,449,450,452,454,455,456,459]],
['Отчество',[]],
['identity',[4,49,53,55]],
['document',[4,49,53,55]],
['Документ',[]],
['удостоверяющий',[4,53,55]],
['личность',[4,53,55]],
['series',[4,53,55,58]],
['nillable',[4,31,33,53,55,58]],
['true',[4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500]],
['Серия',[]],
['number',[4,7,9,17,22,53,55,57,72,74,79,82,150,155,156,161,224,432]],
['Номер',[]],
['физического',[4,31,33,74,79,221,222]],
['цифр',[4,31,33]],
['employee',[4,17,70,72,225]],
['Сотрудник',[]],
['post',[4,17,25,72]],
['Должность',[]],
['basisauthority',[4,17,18,72]],
['Основание',[]],
['полномочий',[4,17,18,19,22]],
['документа',[4,7,8,9,10,17,19,22,65,66,70,71,74,79,221,224,431,432]],
['основания',[4,17,19,22]],
['date',[4,7,8,14,17,19,50,51,52,70,71,72,74,79,221,224,225,429,432]],
['Дата',[]],
['phone',[4,17,24,72]],
['Телефон',[]],
['signerdata',[4,70,74,79,221,225]],
['Данные',[]],
['подписи',[4,70]],
['сотрудника',[4,70,72]],
['2016-07-15',[4,70,71]],
['Подписанты',[]],
['organization',[4,70,73,225]],
['Организация',[]],
['contract',[4,7,74,79,221,224,431,432]],
['Информация',[]],
['договоре',[4,7]],
['аренды',[4,7,8,9]],
['лесного',[4,4,7,8,9,39,42,74,79,221,227,248,254,269,280,293,363,364,368,431,433,434,435,456,458,480,498]],
['участка',[4,7,8,9,74,79,221,227,248,254,269,280,293,363,364,368,431,433,434,435]],
['ином',[4,7]],
['документе',[4,7]],
['contracttype',[4,7,10,480,485]],
['договора',[4,7,8,9]],
['иного',[4,7,8,9]],
['location',[4,39,74,79,82,85,93,97,105,110,115,117,119,122,124,129,131,136,138,141,149,152,154,164,169,170,171,172,174,187,188,189,192,197,199,200,201,202,206,221,227,241,242,244,258,259,261,262,263,265,266,269,270,272,273,280,288,289,292,293,294,302,304,305,307,308,310,311,314,317,318,324,328,329,331,336,337,339,343,344,346,349,350,352,357,358,362,363,364,367,369,370,380,401,402,406,412,413,417,422,424,431,434,438,440,445,451,456,457,462,464,466,470]],
['Местоположение',[]],
['forestry',[4,39,41,174,192,206,244,261,266,273,292,302,308,314,324,339,346,352,362,367,380,406,417,440,451,457,464,470]],
['лесничества',[4,4,39,39,41,41,43,74,79,82,94,95,221,280,317]],
['лесопарка',[4,39,41]],
['элемент',[4,39,41,43,45,74,79,82,200,201,202,210,212,213,220,221,227,228,229,239,479]],
['справочника',[4,39,41,43,45,74,79,82,200,201,202,210,212,213,220,221,227,228,229,239]],
['Лесничества',[]],
['subforestry',[4,39,43,174,192,206,244,261,266,273,292,302,308,314,324,339,346,352,362,367,380,406,417,440,451,457,464,470]],
['участкового',[4,39,43]],
['Участковые',[]],
['tract',[4,39,45,174,192,206,244,261,266,273,292,302,308,314,324,339,346,352,362,367,380,406,417,440,451,457,464,470]],
['урочища',[4,4,39,39,45,45]],
['наличии',[4,39,45,74,79,221,227,241,262,276,280,328,329,330,336]],
['Урочища',[]],
['quarter',[4,39,42,174,192,206,244,261,266,273,292,302,308,314,324,339,346,352,362,367,380,406,417,440,451,457,464,470,480,495]],
['Лесного',[]],
['квартала',[4,39,42]],
['taxationunit',[4,39,44,74,79,174,192,206,221,227,244,258,259,261,266,273,292,302,308,314,324,339,346,352,362,367,380,406,417,440,451,457,464,470,480,497]],
['лесотаксационного',[4,39,44]],
['выдела',[4,39,44]],
['cuttingarea',[4,39,40,174,192,206,244,261,266,273,292,302,308,314,324,339,346,352,362,367,380,406,417,440,451,457,464,470,480,487]],
['лесосеки',[4,39,40,480,487]],
['file',[4,5,6,26,74,79,80,81]],
['Уникальный',[]],
['идентификатор',[4,4,26,28,61,63,65,65,66,68,480,491]],
['файла',[4,26,27,28,29]],
['архиве',[4,26,28]],
['может',[4,26,28,74,74,79,79,82,170,179,180,183,221,227,258,259,261]],
['быть',[4,26,28]],
['guid',[4,26,28,65,66,437,480,491]],
['набор',[4,26,28]],
['символов',[4,26,28]],
['уникальный',[4,4,26,26,28,28,65,66,480,491]],
['внутри',[4,26,28]],
['всего',[4,26,28,74,74,79,79,82,82,170,170,179,179,180,180,182,186,221,280,369,370,371,373,374,376,377,379,381,383,384,386,388,390,391,393,474,475]],
['xml-документа',[4,26,28]],
['любой',[4,26,28]],
['hash',[4,26,28]],
['например',[4,26,28]],
['Оригинальное',[]],
['наименование',[4,4,26,29,36,38,39,41,43,45,46,53,55,56,61,64,65,67,74,79,221,280,310,311,315,328,329,332,336,337,341,349,350,354,445,453]],
['расширение',[4,4,26,26,27,29,74,79,82,125]],
['extension',[4,6,26,27,81]],
['Расширение',[]],
['оригинального',[4,26,27]],
['signature',[4,6,26,30,81]],
['base64binary',[4,26,30]],
['формате',[4,26,30]],
['pkcs',[4,26,30]],
['detached',[4,26,30]],
['периода',[4,14,50]],
['даты',[4,14]],
['month',[4,14,15]],
['Месяц',[]],
['integer',[4,14,15,16]],
['mininclusive',[4,14,15,16,480,482,483,484,489,494,499]],
['maxinclusive',[4,14,15,480,482,483,484,489,494,499]],
['year',[4,14,16,74,79,115,122,149,169,221,280,401,402,411,430,438,444,480,500]],
['period',[4,50]],
['начальная',[4,4,50,50,51]],
['конечная',[4,4,50,50,52]],
['дата',[4,4,7,8,17,19,50,51,52]],
['begin',[4,50,51]],
['Начальная',[]],
['Конечная',[]],
['coordinates',[4,11]],
['Координаты',[]],
['latitude',[4,11,12]],
['decimal',[4,11,12,13,74,79,221,227,228,229,233,480,482,483,484,489,494,499]],
['Широта',[]],
['longitude',[4,11,13]],
['Долгота',[]],
['attachments',[4,5,74,79,80,479]],
['maxoccurs',[4,5,74,79,80,81,82,83,84,85,87,88,89,90,91,92,93,94,96,97,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,143,144,145,146,147,148,149,150,151,152,153,154,155,156,163,164,165,166,167,168,169,170,171,172,179,180,187,188,189,193,194,195,196,197,198,199,200,201,202,212,213,221,227,228,229,241,242,248,249,254,255,258,259,262,263,265,266,269,270,272,273,276,277,280,281,282,288,289,293,294,304,305,307,308,310,311,317,318,328,329,336,337,343,344,349,350,357,358,363,364,369,370,394,395,401,402,412,413,420,421,422,423,424]],
['unbounded',[4,5,74,79,80,81,82,83,84,85,87,88,89,90,91,92,93,94,96,97,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,143,144,145,146,147,148,149,150,151,152,153,154,155,156,163,164,165,166,167,168,169,170,171,172,179,180,187,188,189,193,194,195,196,197,198,199,200,201,202,212,213,221,227,228,229,241,242,248,249,254,255,258,259,262,263,265,266,269,270,272,273,276,277,280,281,282,288,289,293,294,304,305,307,308,310,311,317,318,328,329,336,337,343,344,349,350,357,358,363,364,369,370,394,395,401,402,412,413,420,421,422,423,424]],
['serviceinfo',[4,65,74,79,437,479]],
['Служебная',[]],
['информация',[4,4,7,65,74,79,221,223]],
['услуги',[4,65]],
['provider',[4,65,68,437]],
['информационной',[4,65,68]],
['системы',[4,65,68,480,486]],
['поставщика',[4,65,68]],
['данных',[4,65,68]],
['Версия',[]],
['схемы',[4,65,67,69]],
['обмена',[4,65,67,69]],
['51a51362-192a-45c6-8947-33e97f420dbf',[4,65,66]],
['forestdevelopmentproject',[74,79,82,83,84,85,87,88,89,90,91,92,93,94,96,97,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,143,144,145,146,147,148,149,150,151,152,153,154,163,164,165,166,167,168,169,170,171,172,187,188,189,193,194,195,196,197,198,199,200,212,221,227,228,229,241,242,248,249,254,255,258,259,262,263,269,270,276,277,280,281,282,288,289,293,294,304,305,310,311,317,318,328,329,336,337,343,344,349,350,357,358,363,364,369,370,394,395,401,402,412,413,420,421,422,423,424,479]],
['Корневой',[]],
['Проект',[]],
['освоения',[74,79,221,280,310,426,429,479]],
['лесов',[74,79,82,83,87,89,92,111,112,116,150,151,153,163,200,212,213,219,221,227,228,229,238,241,248,249,252,253,280,281,282,284,310,311,315,316,317,336,337,342,369,370,387,401,402,409,426,427,429,431,436,466,479,480,489]],
['проекта',[74,79,221,225,280,310,429]],
['preamble',[74,79,431,479]],
['Преамбула',[]],
['титульный',[74,79,431]],
['лист',[74,79,431]],
['местоположения',[74,79,221,280,310,336,431,434,456]],
['totalarea',[74,79,431,435]],
['area',[74,79,82,93,105,110,115,117,119,122,124,129,131,136,138,149,152,154,164,169,170,171,172,173,179,180,181,182,183,184,185,186,187,188,189,190,197,199,200,201,202,203,212,213,214,221,227,228,229,231,241,242,243,248,249,250,258,259,260,280,281,282,283,284,288,289,290,293,294,295,296,297,298,299,300,301,304,305,306,310,311,312,313,336,337,338,343,344,345,349,350,351,357,358,359,363,364,365,369,370,371,372,373,374,375,376,381,382,383,384,385,386,394,395,396,398,399,400,401,402,403,412,413,415,418,419,422,424,431,435,438,439,445,446,462,463,466,467,480,482]],
['Площадь',[]],
['grounds',[74,79,431,433]],
['предоставления',[74,79,431,433]],
['usagetype',[74,79,221,427,431,436]],
['видов',[74,75,79,82,89,90,94,95,106,107,111,112,120,125,126,132,133,145,146,165,166,187,188,193,194,221,227,262,280,317,369,401,412,427,431,436]],
['использования',[74,79,82,83,87,221,280,363,364,368,427,428,431,436,480,489]],
['правоустанавливающего',[74,79,221,224,431,432]],
['general',[74,79,221,479]],
['Общие',[]],
['сведения',[4,31,36,53,74,74,79,79,82,101,102,106,107,111,112,114,125,126,132,133,145,146,165,166,187,188,193,194,221,221,226,227,241,254,262,276,280,310,328,336,425]],
['лице',[74,79,221,425]],
['использующем',[74,79,221,425]],
['лесной',[74,79,82,150,151,153,163,221,226,227,228,229,240,420,421,423,425,480,498]],
['участок',[74,79,221,226,425]],
['address',[74,79,221,222]],
['Адрес',[]],
['contactinformation',[74,79,221,223]],
['Контактная',[]],
['useperiod',[74,79,221,428]],
['float',[74,79,82,150,155,156,159,160,221,227,241,242,247,280,317,318,319,321,322,325,328,329,330,333,349,350,356,369,370,377,378,379,388,389,390,391,392,393,412,413,416,428,445,448]],
['Срок',[]],
['executiveauthority',[74,79,221,226]],
['органе',[74,79,221,226]],
['государственной',[74,79,221,226]],
['власти',[74,79,221,226]],
['местного',[74,79,221,226]],
['самоуправления',[74,79,221,226]],
['предоставившем',[74,79,221,226]],
['аренду',[74,79,221,226,227,258]],
['постоянное',[74,79,221,226,227,258]],
['бессрочное',[74,79,221,226,227,258]],
['пользование',[74,79,221,226,227,258]],
['установившем',[74,79,221,226]],
['сервитут',[74,79,221,226,227,258]],
['предусмотренный',[74,79,221,226]],
['статьей',[74,79,221,226]],
['Земельного',[]],
['кодекса',[74,79,221,226]],
['Российской',[]],
['Федерации',[]],
['публичный',[74,79,221,226,227,258]],
['regulations',[74,79,221,280,328,329,334,426]],
['Перечень',[]],
['законодательных',[74,79,221,426]],
['иных',[74,79,82,125,126,128,130,193,194,221,227,262,276,426]],
['нормативно-правовых',[74,79,221,426]],
['актов',[74,79,221,426]],
['нормативно-технических',[74,79,221,426]],
['методических',[74,79,221,426]],
['проектных',[74,79,221,426]],
['документов',[74,79,221,426,480,485]],
['основе',[74,79,221,426]],
['которых',[74,79,82,83,84,94,96,101,104,106,109,120,121,123,139,140,145,148,165,168,200,201,221,227,258,280,343,349,357,426]],
['разработан',[74,79,221,426]],
['проект',[74,74,79,221,426,479]],
['validityperiod',[74,79,221,429]],
['действия',[74,79,221,280,310,429]],
['developer',[74,79,221,225]],
['Разработчик',[]],
['yearforestmanagement',[74,79,221,430]],
['последнего',[74,79,221,430]],
['лесоустройства',[74,79,221,430]],
['info',[74,79,221,227]],
['лесном',[74,79,82,89,90,92,111,114,118,125,128,130,132,135,137,150,151,153,155,163,165,166,193,198,200,212,221,227,228,280,328,336,401,420,421,466]],
['участке',[74,79,82,89,90,92,111,114,118,125,128,130,132,135,137,150,151,153,155,163,165,166,193,198,200,212,221,227,228,280,328,336,401,420,421,466]],
['listquarterstaxationunit',[74,79,221,227,258]],
['предоставленных',[74,79,221,227,258]],
['отношении',[74,79,221,227,258]],
['установлен',[74,79,221,227,258]],
['лесных',[74,79,82,94,95,96,98,99,101,102,104,106,107,109,111,118,120,123,125,130,132,137,139,140,142,143,145,146,148,150,163,165,168,193,194,198,200,201,202,208,221,227,228,258,262,280,363,412,413,419,420,423,456,466,474]],
['кварталов',[74,79,221,227,258]],
['лесотаксационных',[74,79,82,83,84,94,96,101,104,106,109,120,121,123,139,140,145,148,165,168,170,171,200,201,221,227,258,280,343,349,357,363]],
['выделов',[74,79,82,83,84,94,96,101,104,106,109,120,121,123,139,140,145,148,165,168,170,171,200,201,221,227,258,280,343,349,357,363]],
['частей',[74,79,221,227,258]],
['поле',[74,79,221,227,258,259,261]],
['присутствовать',[74,79,221,227,258,259,261]],
['только',[74,79,221,227,258,259,261]],
['одно',[74,79,221,227,258,259,261]],
['значение',[74,79,221,227,258,259,261]],
['перечисления',[74,79,221,227,258,259,261]],
['через',[74,79,221,227,258,259,261]],
['запятую',[74,79,221,227,258,259,261]],
['тире',[74,79,221,227,258,259,261]],
['эксплуатационная',[74,79,221,227,258,259,260]],
['distributionspecialpurpose',[74,79,221,227,248]],
['Распределение',[]],
['площади',[74,79,221,227,248]],
['видам',[74,79,221,227,248,280,363,412,413,419]],
['целевого',[74,79,221,227,248]],
['назначения',[74,79,221,227,248]],
['защитные',[74,79,221,227,248,280,412,413,418]],
['категориям',[74,79,221,227,248]],
['эксплуатационные',[74,79,221,227,248]],
['резервные',[74,79,221,227,248]],
['леса',[74,79,221,227,248]],
['specialpurpose',[74,79,82,200,212,213,219,221,227,228,229,238,248,249,253,280,310,311,316,336,337,342,369,370,387,401,402,409]],
['Целевое',[]],
['назначение',[74,79,82,200,212,213,219,221,227,228,229,238,248,249,253,280,310,311,316,336,337,342,369,370,387,401,402,409]],
['protectioncategory',[74,79,221,227,248,249,252]],
['Категория',[]],
['защитных',[74,79,221,227,248,249,252,280,412]],
['percent',[74,79,82,200,201,202,208,221,227,248,249,251,480,494]],
['Процент',[]],
['averagetaxationrates',[74,79,221,227,228]],
['Таксационная',[]],
['характеристика',[74,74,75,76,79,79,82,82,83,86,89,89,90,92,94,95,111,116,125,128,132,135,145,146,150,151,153,193,196,221,221,227,227,228,269,280,280,293,304,317,369,401,412,420,421,445,445,447]],
['насажденийна',[74,79,221,227,228]],
['farm',[74,79,82,200,212,213,215,221,227,228,229,235,280,281,282,285,480,488]],
['Справочник',[]],
['Хозяйства',[]],
['tree',[74,79,82,150,155,156,162,170,171,172,176,200,201,202,209,221,227,228,229,239,280,281,282,286,343,344,347]],
['Преобладающая',[]],
['порода',[74,74,79,79,82,82,150,155,156,162,170,171,172,176,200,201,202,209,221,221,227,228,229,239,262,263,268,280,280,281,282,286,343,344,347]],
['Указывается',[]],
['Породы',[]],
['древесины',[74,79,82,193,194,200,201,212,221,227,228,229,239,280,281,466,480,489,499]],
['Возраст',[]],
['насаждения',[74,79,221,227,228,229,230,233,234]],
['bonitet',[74,79,221,227,228,229,232]],
['Бонитет',[]],
['completeness',[74,79,221,227,228,229,233,480,484]],
['Полнота',[]],
['volume',[74,75,78,79,82,85,91,97,103,108,113,115,122,127,134,141,147,149,167,169,191,195,200,201,202,211,221,227,228,229,240,241,242,247,280,349,350,356,369,370,371,373,374,376,377,379,381,383,384,386,388,390,391,393,401,402,410,438,443,456,461]],
['valuecutting',[74,79,82,200,201,202,204,211,212,213,217,218,221,227,228,229,236,237,240,280,401,402,404,405,410,445,449,450,454,455,466,468,469,472,473,480,499]],
['Средний',[]],
['запас',[74,74,79,79,82,82,94,99,139,143,200,200,201,202,204,211,212,213,217,218,221,227,228,229,237,240,280,401,402,404,405,410,445,449,450,454,455,466,468,469,472,473]],
['насаждений',[74,79,82,111,118,120,123,125,130,132,137,150,163,165,168,170,179,180,186,193,198,200,201,202,208,221,227,228,229,237,240,280,310,311,312,313,420,423,466,468,472]],
['покрытых',[74,79,221,227,228,229,240]],
['растительностью',[74,79,221,227,228,229,240]],
['ripeandoverripe',[74,79,221,227,228,229,237]],
['спелых',[74,79,82,170,179,180,186,200,201,202,208,221,227,228,229,237]],
['перестойных',[74,79,82,170,179,180,186,200,201,202,208,221,227,228,229,237]],
['growth',[74,79,221,227,228,229,236]],
['прирост',[74,79,221,227,228,229,236]],
['запасу',[74,79,221,227,228,229,236]],
['composition',[74,79,221,227,228,229,234]],
['Состав',[]],
['speciallyprotectednaturalareas',[74,79,221,227,269]],
['Характеристика',[]],
['имеющихся',[74,79,221,227,269]],
['границах',[74,79,221,227,269]],
['особо',[74,74,79,79,221,221,227,227,269,269,270,275]],
['охраняемых',[74,79,221,227,269]],
['природных',[74,79,221,227,269]],
['территорий',[74,79,82,125,126,128,130,221,227,269]],
['объектов',[74,79,82,111,116,118,120,123,125,126,128,130,132,133,135,137,150,151,163,193,196,198,221,227,269,270,271,280,304,317,349,420,421,423,445,480,498]],
['границы',[74,79,221,227,269]],
['режим',[74,74,79,79,221,221,227,227,269,269,270,274]],
['особой',[74,79,221,227,269]],
['охраны',[74,79,221,227,262,263,264,269,270,274]],
['мероприятия',[74,74,79,79,82,83,84,221,221,227,227,269,269,270,271,280,280,317,318,326,336,337,340,343,349,350,353,357,401,402,408,412,413,418,438,441,445,452]],
['сохранению',[74,79,221,227,269]],
['биоразнообразия',[74,79,221,227,269]],
['speciallyprotectednaturalarea',[74,79,221,227,269,270,275]],
['Особо',[]],
['охраняемая',[74,79,221,227,269,270,275]],
['природная',[74,79,221,227,269,270,275]],
['территория',[74,79,221,227,269,270,275]],
['securitymode',[74,79,221,227,269,270,274]],
['Режим',[]],
['event',[74,79,221,227,269,270,271]],
['Мероприятия',[]],
['сохранениию',[74,79,221,227,269,270,271]],
['Расположение',[]],
['ООПТ',[]],
['contamination',[74,79,221,227,241]],
['загрязнения',[74,79,221,227,241,242,245,247,280,363,364,366,412,413,414]],
['числе',[74,79,82,170,179,180,184,221,227,241,445,449,454]],
['нефтяного',[74,79,221,227,241]],
['радиоактивного',[74,79,221,227,241,280,363,412]],
['typecontamination',[74,79,221,227,241,242,245]],
['unittype',[74,79,85,88,97,100,115,122,141,144,149,169,221,227,241,242,246,280,317,318,327,328,329,335,349,350,355,438,442,456,460,474,478]],
['Единица',[]],
['измерения',[74,79,221,227,241,242,246,280,317,318,327,328,329,335,349,350,355,438,442,456,460,474,478]],
['Количественные',[]],
['показатели',[74,79,221,227,241,242,247]],
['rareplantsanimals',[74,79,221,227,262]],
['мест',[74,79,221,227,262,280,369,401]],
['обитания',[74,79,221,227,262]],
['редких',[74,79,221,227,262]],
['находящихся',[74,79,221,227,262]],
['угрозой',[74,79,221,227,262]],
['исчезновения',[74,79,221,227,262]],
['животных',[74,79,221,227,262]],
['произрастания',[74,79,221,227,262]],
['деревьев',[74,79,82,150,155,221,227,262,280,369,370,388]],
['кустарников',[74,79,221,227,262]],
['лиан',[74,79,221,227,262]],
['растений',[74,79,82,94,95,96,98,99,101,102,145,146,148,221,227,262,280,369,370,384]],
['species',[74,79,221,227,262,263,268]],
['restrictions',[74,79,221,227,262,263,267]],
['Ограничения',[]],
['basisprotection',[74,79,221,227,262,263,264]],
['surveys',[74,79,221,227,276]],
['материалах',[74,79,221,227,276]],
['специальных',[74,79,221,227,276]],
['изысканий',[74,79,221,227,276]],
['исследований',[74,79,221,227,276]],
['обследований',[74,79,221,227,276]],
['surveymaterials',[74,79,221,227,276,277,279]],
['Материалы',[]],
['изыскания',[74,79,221,227,276,277,279]],
['обследования',[74,79,221,227,276,277,279]],
['requisites',[74,79,221,227,276,277,278]],
['реквизиты',[74,79,221,227,254,255,256,276,277,278]],
['encumbrances',[74,79,221,227,254]],
['обременениях',[74,79,221,227,254]],
['typeencumbrance',[74,79,221,227,254,255,257]],
['обременения',[74,79,221,227,254,255,257]],
['borderarea',[74,79,221,227,254,255,256]],
['objects',[74,79,221,420]],
['Создание',[]],
['эксплуатация',[74,79,82,101,104,106,109,125,132,193,221,420]],
['инфраструктуры',[74,79,82,120,123,150,151,153,163,193,196,198,221,420,421,423,480,498]],
['locationobject',[74,79,82,89,92,111,116,120,123,125,128,132,135,193,196,221,420,421]],
['существующих',[74,79,82,89,92,111,116,125,128,132,135,150,151,153,193,196,221,420,421,445]],
['проектируемых',[74,75,76,77,78,79,82,83,86,89,90,92,101,102,106,107,111,112,116,125,126,128,132,133,135,145,146,150,151,153,165,166,170,171,187,188,193,194,196,221,280,317,412,420,421,438,445,462,465]],
['locationobjectrow',[74,79,82,89,92,93,111,116,117,120,123,124,125,128,129,132,135,136,150,151,152,153,154,193,196,197,221,420,421,422,445]],
['volumecuttings',[74,79,82,111,118,125,130,132,137,150,163,193,198,221,420,423]],
['Проектируемый',[]],
['объем',[74,74,75,78,79,79,82,82,111,118,125,130,132,137,150,163,165,168,193,198,200,212,221,221,280,280,317,318,321,322,349,350,356,369,370,371,372,374,375,377,378,381,382,384,385,388,389,391,392,420,423,438,443,445,449,450,454,455,456,461,466,480,489,499]],
['рубок',[74,79,82,111,118,125,130,132,137,150,163,165,168,193,198,200,201,202,208,210,212,213,220,221,420,423,445,449,450,454,455,466,480,490]],
['создании',[74,79,82,111,118,125,128,130,150,163,221,420,423]],
['volumecuttingsrow',[74,79,82,111,118,119,125,130,131,132,137,138,150,163,164,193,198,199,221,420,423,424,466]],
['measures',[74,79,221,280]],
['охране',[74,79,221,280,349]],
['защите',[74,79,221,280,369]],
['воспроизводству',[74,79,221,280]],
['characteristicfireclasses',[74,79,221,280,293]],
['территории',[74,79,221,280,293]],
['классам',[74,79,221,280,293]],
['пожарной',[74,79,221,280,293,294,296,297,298,299,300,301,328]],
['опасности',[74,79,221,280,293,294,296,297,298,299,300,301]],
['areafireclasses',[74,79,221,280,293,294,296,297,298,299,300,301]],
['класса',[74,79,221,280,293,294,296,297,298,299,300,301]],
['общая',[74,74,79,79,82,94,95,221,280,293,294,295]],
['middleclass',[74,79,221,280,293,294,303]],
['класс',[74,79,221,280,293,294,303]],
['characteristicwaterobjects',[74,79,221,280,304]],
['водных',[74,79,82,125,126,128,130,221,280,304,349]],
['waterobject',[74,79,221,280,304,305,309]],
['Водный',[]],
['объект',[74,74,79,79,221,221,280,280,304,305,309,317,318,323,466,471]],
['designedfireprevention',[74,79,221,280,317]],
['Обоснование',[]],
['объемов',[74,75,79,82,89,90,106,107,111,112,125,126,132,133,145,146,165,166,193,194,221,280,317,369,401,412]],
['сроков',[74,79,82,94,98,221,280,317]],
['выполнения',[74,79,221,280,317,318,320]],
['мероприятий',[74,79,82,101,102,120,121,165,168,221,280,317,318,320,336,369,401,412,438,480,498]],
['противопожарному',[74,79,221,280,317]],
['обустройству',[74,79,221,280,317]],
['учетом',[74,79,221,280,317]],
['созданных',[74,79,221,280,317]],
['использовании',[74,79,82,89,92,111,112,116,150,151,153,163,221,280,317,466]],
['соответствии',[74,79,221,280,317,328,329,334]],
['лесохозяйственным',[74,79,82,94,95,221,280,317]],
['регламентом',[74,79,82,94,95,221,280,317]],
['территориальное',[74,79,221,280,317]],
['размещение',[74,79,221,280,317]],
['firepreventionobject',[74,79,221,280,317,318,323]],
['Объект',[]],
['противопожарного',[74,79,221,280,317,318,323]],
['обустройства',[74,79,221,280,317,318,323]],
['enumeration',[74,79,221,280,310,311,315,317,318,320,323,326,328,329,332,334,336,337,341,363,364,366,412,413,414,480,481,488,490,492,496,498]],
['typeevent',[74,79,221,280,317,318,326]],
['need',[74,79,221,280,317,318,325,328,329,333]],
['Потребность',[]],
['availability',[74,79,221,280,317,318,319,328,329,330]],
['наличие',[74,79,221,280,317,318,319]],
['designedtotalvolume',[74,79,221,280,317,318,322]],
['общий',[74,79,221,280,317,318,322,401,402,410]],
['designedannualvolume',[74,79,221,280,317,318,321]],
['ежегодный',[74,74,79,79,221,221,280,280,317,318,321,369,370,371,372,374,375,377,378,381,382,384,385,388,389,391,392]],
['deadlines',[74,79,221,280,317,318,320]],
['Сроки',[]],
['fireequipment',[74,79,221,280,328]],
['потребности',[74,79,221,280,328]],
['технике',[74,79,221,280,328]],
['оборудовании',[74,79,221,280,328]],
['снаряжении',[74,79,221,280,328]],
['инвентаре',[74,79,221,280,328]],
['действующими',[74,79,221,280,328,329,334]],
['нормативами',[74,79,221,280,328,329,334]],
['Имеется',[]],
['Проектируется',[]],
['приобретение',[74,79,221,280,328,329,333]],
['аренда',[74,79,221,280,328,329,333]],
['изготовление',[74,79,221,280,328,329,333]],
['Место',[]],
['расположения',[74,79,221,280,288,289,292,310,311,314,328,329,331,336,337,339,343,344,346,349,350,352,357,358,362,363,364,367,369,370,380,401,402,406,412,413,417]],
['prevention',[74,79,221,280,369]],
['планируемых',[74,79,221,280,369,401]],
['профилактических',[74,79,221,280,369]],
['указанием',[74,79,82,94,98,221,280,310,336,363,369,401]],
['проведения',[74,79,82,94,98,139,142,170,178,221,280,369,401,402,411,438,444]],
['treatmentttrees',[74,79,221,280,369,370,388]],
['Лечение',[]],
['Всего',[]],
['annualvolume',[74,79,221,280,369,370,371,372,374,375,377,378,381,382,384,385,388,389,391,392]],
['Ежегодный',[]],
['pesticideapplication',[74,79,221,280,369,370,381]],
['Применение',[]],
['пестицидов',[74,79,221,280,369,370,381]],
['предотвращения',[74,79,221,280,369,370,381]],
['появления',[74,79,221,280,369,370,381]],
['очагов',[74,79,221,280,336,337,340,341,369,370,381]],
['вредных',[74,79,221,280,336,337,340,341,369,370,381]],
['организмов',[74,79,221,280,336,337,340,341,369,370,381]],
['fertilizeruse',[74,79,221,280,369,370,371]],
['Использование',[]],
['удобрений',[74,79,221,280,369,370,371]],
['improvingconditions',[74,79,221,280,369,370,377]],
['Улучшение',[]],
['условий',[74,79,221,280,369,370,377]],
['habitatprotection',[74,79,221,280,369,370,374]],
['Охрана',[]],
['местообитаний',[74,79,221,280,369,370,374]],
['sowing',[74,79,221,280,369,370,384,394,395,400]],
['Посев',[]],
['травянистых',[74,79,221,280,369,370,384]],
['нектароносных',[74,79,221,280,369,370,384]],
['usepheromones',[74,79,221,280,369,370,391]],
['феромонов',[74,79,221,280,369,370,391]],
['fociharmfulorganisms',[74,79,221,280,336]],
['необходимых',[74,79,82,89,90,221,280,336]],
['ликвидации',[74,79,221,280,336,337,340]],
['measure',[74,79,93,115,117,122,124,129,136,149,152,154,169,197,221,280,336,337,340,422,438,441,445,452]],
['необходимые',[74,79,221,280,336,337,340]],
['damagedeath',[74,79,221,280,310]],
['повреждении',[74,79,221,280,310]],
['гибели',[74,79,221,280,310,311,315]],
['начало',[74,79,221,280,310]],
['причин',[74,79,221,280,310,311,315]],
['повреждения',[74,79,221,280,310,311,315]],
['areadamage',[74,79,221,280,310,311,312]],
['поврежденных',[74,79,221,280,310,311,312]],
['погибших',[74,79,221,280,310,311,312,313]],
['нарастающим',[74,79,221,280,310,311,312,313]],
['итогом',[74,79,221,280,310,311,312,313]],
['areadeath',[74,79,221,280,310,311,313]],
['sanitaryrecreationalmeasures',[74,79,221,280,401]],
['санитарно-оздоровительных',[74,79,221,280,401]],
['sanritaryrecreationalmeasure',[74,79,221,280,401,402,408]],
['санитарно-оздоровительного',[74,79,221,280,401,402,408]],
['Вырубаемый',[]],
['liquidvolume',[74,79,82,93,117,119,124,129,131,136,138,152,154,164,197,199,200,212,213,217,221,280,401,402,405,422,424,445,450,466,469]],
['ликвидный',[74,74,79,82,200,212,213,217,221,280,401,402,405,445,449,450,466,468,469]],
['businessvolume',[74,79,221,280,401,402,404]],
['деловой',[74,79,221,280,401,402,404]],
['rationale',[74,79,221,280,401,402,407]],
['zonesradioactivecontamination',[74,79,221,280,412]],
['зонах',[74,79,221,280,412]],
['если',[74,79,221,280,363,412]],
['таковые',[74,79,221,280,363,412]],
['имеются',[74,79,221,280,363,412]],
['contaminatedzone',[74,79,221,280,363,364,366,412,413,414]],
['Зона',[]],
['слабая',[74,79,221,280,363,364,366,412,413,414]],
['средняя',[74,79,221,280,363,364,366,412,413,414]],
['сильная',[74,79,221,280,363,364,366,412,413,414]],
['installationwarningboards',[74,79,221,280,412,413,416]],
['Установка',[]],
['предупреждающих',[74,79,221,280,412,413,416]],
['аншлагов',[74,79,221,280,412,413,416]],
['radiationcontrol',[74,79,221,280,412,413,419]],
['Радиационный',[]],
['контроль',[74,79,221,280,412,413,415,419]],
['ресурсов',[74,79,82,94,95,96,98,99,139,140,142,143,193,194,221,280,363,412,413,419,456,474]],
['dosimetriccontrol',[74,79,221,280,412,413,415]],
['Дозиметрический',[]],
['проведении',[74,79,221,280,412,413,415]],
['лесохозяйственных',[74,79,221,280,412,413,415]],
['работ',[74,75,76,77,78,79,82,89,90,94,98,106,107,111,112,114,125,126,132,133,139,142,145,146,165,166,170,178,187,188,193,194,221,280,412,413,415,462,465]],
['otherevents',[74,79,221,280,412,413,418]],
['Прочие',[]],
['listtaxationunitradioactivezone',[74,79,221,280,363]],
['Ведомость',[]],
['входящих',[74,79,221,280,363]],
['зоны',[74,79,221,280,363]],
['ограничений',[74,79,221,280,363]],
['участков',[74,79,221,280,363]],
['заготовки',[74,79,82,94,98,99,139,143,170,171,179,200,212,221,280,363,456,459,461,474,476,480,483]],
['usagerestriction',[74,79,221,280,363,364,368]],
['Ограничение',[]],
['areaneedreforestation',[74,79,221,280,288]],
['земель',[74,79,82,111,114,221,280,288,289,291,357,358,361,394,395,397]],
['нуждающихся',[74,79,221,280,281,282,284,288]],
['лесовосстановлении',[74,79,221,280,288]],
['landcategory',[74,79,221,280,288,289,291,357,358,361,394,395,397]],
['reforestationplan',[74,79,221,280,394]],
['Плановые',[]],
['способы',[74,79,221,280,394]],
['объемы',[74,79,82,94,99,139,143,221,280,281,394,474,476]],
['лесовосстановления',[74,79,82,200,201,202,207,221,280,357,358,360,394]],
['landing',[74,79,221,280,394,395,398]],
['Посадка',[]],
['combined',[74,79,221,280,394,395,396]],
['Комбинированное',[]],
['лесовосстановление',[74,79,221,280,394,395,396,399]],
['natural',[74,79,221,280,394,395,399]],
['Естественное',[]],
['listreforestation',[74,79,221,280,357]],
['планируются',[74,79,221,280,343,357]],
['лесовосстановлению',[74,79,221,280,343,357]],
['conditionsprojectedmethod',[74,79,221,280,357,358,360]],
['Планируемый',[]],
['способ',[74,74,79,79,82,82,170,171,172,177,200,201,202,207,221,280,357,358,360,456,459]],
['listforestcare',[74,79,221,280,343]],
['typecare',[74,79,221,280,281,282,287,343,344,348]],
['ухода',[74,79,221,280,281,282,283,287,343,344,348]],
['Целевая',[]],
['areaforestcare',[74,79,221,280,281]],
['уходе',[74,79,221,280,281,282,284]],
['лесами',[74,79,221,280,281,282,283,284]],
['проектируемые',[74,74,79,79,82,82,83,87,94,94,98,99,139,139,142,143,170,178,221,221,280,280,281,349,350,353,445,452,474,476]],
['виды',[74,74,79,79,82,200,201,202,210,212,213,220,221,280,281,480,485]],
['ежегодные',[74,79,82,94,99,139,143,221,280,281,474,476]],
['воспроизводстве',[74,79,221,280,281]],
['связанные',[74,79,82,120,123,221,280,281,480,498]],
['заготовкой',[74,79,221,280,281,466,480,489]],
['Хозяйство',[]],
['Порода',[]],
['annualarea',[74,79,221,280,281,282,283]],
['Ежегодная',[]],
['площадь',[74,74,79,79,82,170,171,172,173,187,188,189,190,200,201,202,203,212,213,214,221,221,227,228,229,231,241,242,243,248,249,250,258,259,260,280,280,281,281,282,282,283,284,288,289,290,293,294,295,296,297,298,299,300,301,304,305,306,310,311,312,313,336,337,338,343,344,345,349,350,351,357,358,359,363,364,365,401,402,403,431,435,438,439,445,446,462,463,466,467,480,482,483]],
['listprotection',[74,79,221,280,349]],
['проектируются',[74,79,82,83,84,221,280,349]],
['животного',[74,79,221,280,349]],
['растительного',[74,79,221,280,349]],
['мира',[74,79,221,280,349]],
['objectprotection',[74,79,221,280,349,350,354]],
['объекта',[74,79,221,280,349,350,354,445,446,447,448,453,466,467,480,493]],
['строения',[74,79,221,280,349,350,354,445,446,453,466,467]],
['сооружения',[74,79,221,280,349,350,354,445,446,453,466,467]],
['measureprotection',[74,79,221,280,349,350,353]],
['Проектируемые',[]],
['Объем',[]],
['forestuse',[74,79,82,479]],
['виду',[74,79,82]],
['разрешенного',[74,79,82]],
['woodharvesting',[74,79,82,200]],
['Заготовка',[]],
['volumecuttingswood',[74,79,82,200,212]],
['Установленный',[]],
['formcutting',[74,79,82,200,201,202,205,212,213,216,480,490]],
['Форма',[]],
['рубки',[74,79,82,120,123,200,201,202,205,212,213,216]],
['typecutting',[74,79,82,200,201,202,210,212,213,220]],
['Виды',[]],
['rootvolume',[74,79,82,93,117,119,124,129,131,136,138,152,154,164,197,199,200,212,213,218,422,424,445,455,466,473]],
['корневой',[74,74,79,82,200,212,213,218,445,454,455,466,472,473,479]],
['locationcuttings',[74,79,82,200,201]],
['проектируется',[74,74,79,79,82,94,96,101,104,106,109,120,121,123,139,140,145,148,165,168,200,201,221,280,328,329,333]],
['заготовка',[74,74,79,79,82,82,94,94,96,139,139,140,170,200,200,201]],
['averagevolume',[74,79,82,200,201,202,204]],
['Запас',[]],
['средний',[74,74,79,79,82,200,201,202,204,221,227,228,229,236,237,240,280,293,294,303]],
['выделе',[74,79,82,200,201,202,211]],
['samplepercentage',[74,79,82,200,201,202,208]],
['выборки',[74,79,82,200,201,202,208]],
['выборочных',[74,79,82,200,201,202,208]],
['reforestationmethod',[74,79,82,200,201,202,207]],
['resinharvesting',[74,79,82,170]],
['живицы',[74,79,82,170,171,172,175,178,179,480,489,499]],
['technologies',[74,79,82,83,86,94,98,139,142,170,178]],
['технологии',[74,79,82,94,98,139,142,170,178]],
['заготовке',[74,79,82,94,98,139,142,170,178]],
['volumeresource',[74,79,82,83,87,94,99,139,143,170,179]],
['Фонд',[]],
['useful',[74,79,82,170,179,180,186]],
['пригодных',[74,79,82,170,179,180,186]],
['подсочки',[74,79,82,170,171,172,177,179,180,182,186]],
['completion',[74,79,82,170,179,180,181]],
['вовлечены',[74,79,82,170,179,180,181]],
['подсочку',[74,79,82,170,179,180,181]],
['unprofitable',[74,79,82,170,179,180,184]],
['нерентабельные',[74,79,82,170,179,180,184]],
['maybe',[74,79,82,170,179,180,183]],
['Может',[]],
['ежегодно',[74,79,82,170,179,180,183]],
['находиться',[74,79,82,170,179,180,183]],
['подсочке',[74,79,82,170,179,180,183,185]],
['used',[74,79,82,170,179,180,185]],
['Фактически',[]],
['находится',[74,79,82,170,179,180,185]],
['finished',[74,79,82,170,179,180,182]],
['Вышедшие',[]],
['locationresource',[74,79,82,83,84,94,96,139,140,170,171]],
['typeharvesting',[74,79,82,85,97,141,170,171,172,177,456,459]],
['Способ',[]],
['resinoutlet',[74,79,82,170,171,172,175]],
['forestusagevolume',[74,79,82,170,171,172,175,438,443,456,461,474,475,476,480,489]],
['Выход',[]],
['nontimberresourcesharvesting',[74,79,82,139]],
['сбор',[74,79,82,94,96,139]],
['недревесных',[74,79,82,139,140,142,143]],
['биологический',[74,79,82,94,99,139,143]],
['volumeresourcerow',[74,79,82,83,87,88,94,99,100,139,143,144,474]],
['locationresourcerow',[74,79,82,83,84,85,94,96,97,139,140,141,456]],
['foodforestrresourcesharvesting',[74,79,82,94]],
['пищевых',[74,79,82,94,95,96,98,99]],
['лекарственных',[74,79,82,94,95,96,98,99,145,146,148]],
['characteristics',[74,79,82,94,95,187,188,189,191]],
['Общая',[]],
['предусмотренная',[74,79,82,94,95]],
['сбору',[74,79,82,94,98]],
['допустимого',[74,79,82,94,98]],
['объема',[74,79,82,94,98,474]],
['сбора',[74,79,82,94,98,99]],
['фонда',[74,79,82,94,98]],
['биологического',[74,79,82,94,98]],
['запаса',[74,79,82,94,98]],
['hunting',[74,79,82,120]],
['Осуществление',[]],
['деятельности',[74,79,82,120,150,151,153,155,163,165,166,168]],
['сфере',[74,79,82,120]],
['охотничьего',[74,79,82,120]],
['хозяйства',[74,74,79,79,82,83,84,86,87,120,221,227,228,229,235,480,488]],
['создание',[74,74,79,79,82,82,101,101,104,106,106,109,120,123,125,193,221,420]],
['охотничьей',[74,79,82,120,123]],
['созданием',[74,79,82,120,123,150,151,153,163,480,498]],
['locationmeasure',[74,79,82,111,114,120,121,145,148,165,168]],
['проведение',[74,79,82,120,121]],
['биотехнических',[74,79,82,120,121]],
['locationmeasurerow',[74,79,82,111,114,115,120,121,122,145,148,149,165,168,169,438]],
['agriculture',[74,79,82,83]],
['Ведение',[]],
['сельского',[74,79,82,83,84,86,87]],
['технологий',[74,79,82,83,86,101,102,145,146]],
['ведения',[74,79,82,83,86,87]],
['Основные',[]],
['параметры',[74,79,82,83,87]],
['ведению',[74,79,82,83,84]],
['fishing',[74,79,82,89]],
['осуществления',[74,79,82,89,90,92,150,155]],
['рыболовства',[74,79,82,89,90,92]],
['characteristicswork',[74,79,82,89,90,101,102,106,107,111,112,125,126,132,133,145,146,165,166,187,188,193,194]],
['возведению',[74,79,82,89,90]],
['некапитальных',[74,79,82,89,90,92,150,153]],
['строений',[74,79,82,89,90,92,111,116,118,125,128,132,135,150,153]],
['сооружений',[74,79,82,89,90,92,111,116,118,125,126,128,130,132,135,150,153]],
['characteristicsworkrow',[74,75,79,82,89,90,91,101,102,103,106,107,108,111,112,113,125,126,127,132,133,134,145,146,147,165,166,167,187,188,189,191,193,194,195]],
['researchactivities',[74,79,82,165]],
['научно-исследовательской',[74,79,82,165,166,168]],
['образовательной',[74,79,82,165,166,168]],
['программе',[74,79,82,165,166]],
['обоснованием',[74,79,82,165,166]],
['характеристикой',[74,79,82,165,166]],
['осуществление',[74,74,79,79,82,82,120,150,165,165,168]],
['проектируемый',[74,74,79,79,82,82,111,118,125,130,132,137,165,168,193,198,221,280,317,318,321,322,420,423,466,471]],
['проводимых',[74,79,82,165,168]],
['целях',[74,79,82,111,112,116,165,168]],
['recreation',[74,79,82,150]],
['рекреационной',[74,79,82,150,151,153,155,163]],
['treeregister',[74,79,82,150,155]],
['учета',[74,79,82,150,155]],
['дерева',[74,79,82,150,155,156,161]],
['condition',[74,79,82,150,155,156,158]],
['Состояние',[]],
['diameter',[74,79,82,150,155,156,159]],
['Диаметр',[]],
['height',[74,79,82,150,155,156,160]],
['Высота',[]],
['locationcapitalobject',[74,79,82,150,151]],
['капитального',[74,79,82,150,151,163]],
['строительства',[74,79,82,132,137,150,151,163]],
['связанных',[74,79,82,150,151,153,163,466]],
['locationnoncapitalobject',[74,79,82,150,153]],
['forestplantations',[74,79,82,106]],
['плантаций',[74,79,82,106,107,109]],
['характеристиках',[74,79,82,101,102,106,107,111,112,125,126,132,133,145,146,187,188,193,194]],
['обосновании',[74,79,82,101,102,106,107,111,112,125,126,132,133,145,146,187,188,193,194]],
['созданию',[74,79,82,106,107,125,126]],
['эксплуатации',[74,79,82,106,107,125,126,128,130,132,133,135,137]],
['технология',[74,79,82,106,107]],
['создания',[74,79,82,106,107,193,198]],
['locationwork',[74,79,82,101,104,106,109]],
['locationworkrow',[74,79,82,101,104,105,106,109,110,462]],
['forestnurseries',[74,79,82,101]],
['питомников',[74,79,82,101,104]],
['выращиванию',[74,79,82,101,102,145,146]],
['посадочного',[74,79,82,101,102]],
['материала',[74,79,82,101,102]],
['саженцев',[74,79,82,101,102]],
['сеянцев',[74,79,82,101,102]],
['проектируемом',[74,79,82,101,102]],
['объеме',[74,79,82,101,102]],
['видах',[74,79,82,101,102]],
['направленных',[74,79,82,101,102]],
['соблюдение',[74,79,82,101,102]],
['plantgrowing',[74,79,82,145]],
['Выращивание',[]],
['плодовых',[74,79,82,145,146,148]],
['ягодных',[74,79,82,145,146,148]],
['декоративных',[74,79,82,145,146,148]],
['выращивание',[74,74,79,79,82,82,145,145,148]],
['geology',[74,79,82,111]],
['Выполнение',[]],
['геологическому',[74,79,82,111,114]],
['изучению',[74,79,82,111,114]],
['недр',[74,79,82,111,112,114,116,118]],
['разведке',[74,79,82,111,114]],
['добыче',[74,79,82,111,114]],
['полезных',[74,79,82,111,112,114,116,118]],
['ископаемых',[74,79,82,111,112,114,116,118]],
['геологического',[74,79,82,111,112,116,118]],
['изучения',[74,79,82,111,112,116,118]],
['разведки',[74,79,82,111,112,116,118]],
['добычи',[74,79,82,111,112,116,118]],
['рекультивации',[74,79,82,111,114]],
['нарушенных',[74,79,82,111,114]],
['геологическом',[74,79,82,111,114]],
['изучении',[74,79,82,111,114]],
['выполнении',[74,79,82,111,114]],
['также',[74,79,82,111,114]],
['подвергшихся',[74,79,82,111,114]],
['нефтяному',[74,79,82,111,114]],
['иному',[74,79,82,111,114]],
['загрязнению',[74,79,82,111,114]],
['подлежащих',[74,79,82,111,114]],
['hydrology',[74,79,82,125]],
['Строительство',[]],
['водохранилищ',[74,79,82,125,126,128,130]],
['искусственных',[74,79,82,125,126,128,130]],
['морских',[74,79,82,125,126,128,130]],
['речных',[74,79,82,125,126,128,130]],
['портов',[74,79,82,125,126,128,130]],
['строительство',[74,74,79,79,82,82,125,125,132]],
['реконструкция',[74,79,82,125,132]],
['гидротехнических',[74,79,82,125,126,128]],
['строительству',[74,79,82,125,126,132,133]],
['расширению',[74,79,82,125,126]],
['реконструкции',[74,79,82,125,126,128,130,132,133,135,137]],
['строительстве',[74,79,82,125,128,130,132,135]],
['расширении',[74,79,82,125,128,130]],
['эксплуатациигидротехнических',[74,79,82,125,130]],
['linearobjects',[74,79,82,132]],
['линейных',[74,79,82,132,133,135,137]],
['предназначенном',[74,79,82,132,137,193,198]],
['timberprocessing',[74,79,82,193]],
['лесоперерабатывающей',[74,79,82,193,196,198]],
['переработке',[74,79,82,193,194]],
['surveywork',[74,79,82,187]],
['Изыскательские',[]],
['работы',[74,79,82,187]],
['объемах',[74,79,82,187,188]],
['изыскательских',[74,79,82,187,188]],
['местоположение',[4,39,74,74,438,445,462,466]],
['object',[74,93,117,119,124,129,131,136,138,152,154,164,197,199,422,424,445,453,466,471]],
['rootconifervolume',[74,93,117,119,124,129,131,136,138,152,154,164,197,199,422,424,445,454,466,472]],
['хвойных',[74,466,468,472]],
['Ликвидный',[]],
['liquidconifervolume',[74,93,117,119,124,129,131,136,138,152,154,164,197,199,422,424,445,449,466,468]],
['Строка',[]],
['resource',[74,85,88,97,100,141,144,456,458,474,477]],
['ресурса',[74,456,458,474,477]],
['fund',[74,88,100,144,474,475]],
['fundannual',[74,88,100,144,474,476]],
['недревесного',[74,456,458]],
['Протяженность',[]],
['characteristic',[74,75,76,91,93,103,108,113,117,124,127,129,134,136,147,152,154,167,191,195,197,422,445,447]],
['хвойные',[74,445,449,454]],
['обоснование',[74,74,75,76,79,82,89,90,221,280,317,369,401,402,407,412]],
['typework',[74,75,77,91,103,105,108,110,113,127,134,147,167,191,195,462,465]],
['Формы',[]],
['Сплошная',[]],
['рубка',[480,490]],
['Выборочная',[]],
['Мягколиственное',[]],
['Твердолиственное',[]],
['Хвойное',[]],
['typeobject',[480,498]],
['Типы',[]],
['Объекты',[]],
['семеноводства',[480,498]],
['taxationmethod',[480,496]],
['Методы',[]],
['таксации',[480,496]],
['Сплошной',[]],
['перечет',[480,496]],
['Ленточный',[]],
['Круговые',[]],
['площадки',[480,496]],
['постоянного',[480,496]],
['радиуса',[480,496]],
['Реласкопические',[]],
['municipaldistricttype',[480,492]],
['муниципальных',[480,492]],
['образований',[480,492]],
['Регион',[]],
['Район',[]],
['Город',[]],
['Поселение',[]],
['Населенный',[]],
['пункт',[480,492]],
['Простой',[]],
['a-fa-f0-9',[480,491]],
['objectnumber',[480,493]],
['maxlength',[480,487,493]],
['fractiondigits',[480,482,483,484,489,494,499]],
['totaldigits',[480,482,483,484,489,494,499]],
['areacutting',[480,483]],
['Таксационный',[]],
['выдел',[480,497]],
['Квартал',[]],
['coordinatesystem',[480,486]],
['координат',[480,486]],
['связанный',[480,489]],
['agegroup',[480,481]],
['Группы',[]],
['возраста',[480,481]],
['Возмодные',[]],
['значения',[480,481]],
['Молодняки',[]],
['Средневозрастные',[]],
['Приспевающие',[]],
['Спелые',[]],
['Перестойные',[]]
 ];
 return w;
}
        